package com.example.pr_23

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.example.pr_23.databinding.ActivityMainBinding

class MainActivity : Activity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    fun nextActivity(view: View) {
        val intent = Intent(this@MainActivity, SignInActivity::class.java);

        startActivity(intent);
    }
}